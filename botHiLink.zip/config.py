TOKEN_TELEGRAM = "1314039495:AAEG7ccIY4fl5731SusWqKnw51647RbqD0k"
TOKEN_ZABBIX = "e74a38b9472b9d0d91f945f8043a7d00e212b3fd3dafa0b6dd98b3a037f83783"
URL = "http://10.0.1.30/"


'''json = {
        "jsonrpc": "2.0",
        "method": "host.get",
        "params": {
            "output":[
                "hostid",
                "host",
                ],
            "sortorder":"name",
        "selectInterfaces": [
                "ip",
                "available",
                "error"
            ]
    },
    "id": 2,
    "auth": token
    }
jsonpegarstatus = {
        "jsonrpc": "2.0",
        "method": "host.get",
        "params": {
            "filter":{
                "host":[
                    "GAMIL_1"
                ]
            }
    },
    "id": 3,
    "auth": token
    }
jsonpegarevent = {
        "jsonrpc": "2.0",
        "method": "event.get",
        "params": {
            "output":"extend",
            "time_from":"1661742000",
            "time_fill":"1661828400"
    },
"id": 4,
"auth": token
    }'''